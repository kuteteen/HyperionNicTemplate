#import "HyperionWidgets.h"

@interface @@PROJECTNAME@@HyperionWidget : NSObject <HyperionWidget>

@property(nonatomic, retain) UIView *contentView;

@end